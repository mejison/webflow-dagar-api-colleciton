<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Carbon\Carbon;

class ApiController extends Controller
{
    public $api_url = "https://api.webflow.com";
    public $client;

    public function __construct() {
        $this->client = new Client([
            'headers' => [
                'Authorization' => 'Bearer 783c8bcdb08f0f69027cba0e3d04e12874f60cac5e76f53bb8899eaa9ea3e791',
                'accept-version'     => '1.0.0'
            ]
        ]);
    }

    public function getCollection($collection_id) {
        $collections = [
            '5aeb90eec4e6ee6f79489cc1' => 'date'
        ];

		$response = $this->client->request('GET', $this->api_url . "/collections/" . $collection_id . "/items");
        $object = json_decode($response->getBody());
        
        $firstDayThisWeek = Carbon::now()->startOfWeek();
        $lastDayThisWeek = Carbon::now()->addDay(6);

        $fieldFilter = $collections[$collection_id] ? $collections[$collection_id] : 'published-on';

		$response = [];
		$response['items'] = collect($object->items)->filter(function($item) use ($fieldFilter, $firstDayThisWeek, $lastDayThisWeek) {
            
            $publishOn = Carbon::parse($item->{$fieldFilter});
            if($publishOn->between($firstDayThisWeek, $lastDayThisWeek)) {
				return true;
			}
			return false;
		});
		
		$response['collection_id'] = $collection_id;
		return response()->json($response);
    }

    public function getAllCollections(Request $request) {
        $response = $this->client->request('GET', $this->api_url . "/sites/5aeb589ee6f062f8dd767943/collections");
        return response()->json(json_decode($response->getBody()));
    }
}
